Create Table Users(ID int NOT NULL primary Key,FirstName VarChar(255),LastName VarChar(255),Email VarChar(255),City VarChar(255),Salary int,Designation VarChar(255),CreatedTime Time,ModifiedDate Date,IsActive BIT)

Create Table Groups(ID int NOT NULL primary Key, GroupName VarChar(255), Descriptions VarChar(255),CreatedDate Date,ModifiedDate Date,IsActive BIT)

Create Table UserGroups(ID int NOT NULL primary Key,Constraint GroupId Foreign Key(ID) References Groups(ID),Constraint fk_UserId  Foreign Key (ID) References Users(ID),ModifiedDate Date,IsActive BIT)


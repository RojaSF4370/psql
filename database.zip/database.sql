Create Database Employees1;

Alter Database Employees1 Rename To Employeedata;

Drop Database Employeedata;